import React from 'react';

function Footer() {
  return (
    <footer className="App-footer">
      <p>&copy; 2025 AI Blood Bank Intelligence Network. All rights reserved.</p>
      <p>Saving lives through intelligent blood management.</p>
    </footer>
  );
}

export default Footer;