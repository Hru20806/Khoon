import React from 'react';

const AdminIcon = () => (
  <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Admin Dashboard">
    <rect x="6" y="8" width="38" height="34" rx="2" stroke="#c73232" strokeWidth="2" fill="none" />
    <line x1="6" y1="18" x2="44" y2="18" stroke="#c73232" strokeWidth="1.5" />
    <rect x="10" y="24" width="8" height="12" fill="#c73232" opacity="0.6" />
    <rect x="21" y="20" width="8" height="16" fill="#c73232" opacity="0.8" />
    <rect x="32" y="22" width="8" height="14" fill="#c73232" />
  </svg>
);

function RightFlow() {
  return (
    <div className="flow-section right-flow">
      <h3>Admin Dashboard</h3>
      <div className="flow-card">
        <AdminIcon />
        <h4>AI Recommendations</h4>
        <p>Smart system suggests optimal blood units based on type, freshness, and compatibility.</p>
        <ul>
          <li>Optimal unit selection</li>
          <li>Expiry date management</li>
          <li>Cross-bank coordination</li>
        </ul>
      </div>
    </div>
  );
}

export default RightFlow;