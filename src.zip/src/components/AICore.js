import React from 'react';

const BrainIcon = () => (
  <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="AI Brain">
    <circle cx="30" cy="30" r="28" stroke="#c73232" strokeWidth="2" fill="none" />
    <path d="M30 15C25 15 22 18 22 23C22 26 24 28 26 29" stroke="#c73232" strokeWidth="2" fill="none" strokeLinecap="round" />
    <path d="M30 15C35 15 38 18 38 23C38 26 36 28 34 29" stroke="#c73232" strokeWidth="2" fill="none" strokeLinecap="round" />
    <circle cx="30" cy="30" r="8" fill="#c73232" />
    <circle cx="22" cy="38" r="4" fill="#c73232" opacity="0.6" />
    <circle cx="38" cy="38" r="4" fill="#c73232" opacity="0.6" />
    <circle cx="30" cy="45" r="4" fill="#c73232" opacity="0.6" />
  </svg>
);

function AICore() {
  return (
    <div className="ai-core">
      <div className="ai-core-card">
        <BrainIcon />
        <h2>AI Intelligence Core</h2>
        <ul className="core-bullets">
          <li>Real-time blood inventory tracking</li>
          <li>Donor-recipient matching algorithms</li>
          <li>Predictive demand forecasting</li>
          <li>Emergency response optimization</li>
        </ul>
      </div>
    </div>
  );
}

export default AICore;