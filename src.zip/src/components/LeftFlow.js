import React from 'react';

const HospitalIcon = () => (
  <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Hospital">
    <rect x="8" y="12" width="34" height="28" rx="2" stroke="#c73232" strokeWidth="2" fill="none" />
    <path d="M22 20H28M25 17V23" stroke="#c73232" strokeWidth="2" strokeLinecap="round" />
    <line x1="8" y1="28" x2="42" y2="28" stroke="#c73232" strokeWidth="1.5" />
    <circle cx="15" cy="38" r="2" fill="#c73232" />
    <circle cx="25" cy="38" r="2" fill="#c73232" />
    <circle cx="35" cy="38" r="2" fill="#c73232" />
  </svg>
);

function LeftFlow() {
  return (
    <div className="flow-section left-flow">
      <h3>Hospital Requests</h3>
      <div className="flow-card">
        <HospitalIcon />
        <h4>Blood Requests</h4>
        <p>Hospitals submit urgent blood requirements with patient details and compatibility needs.</p>
        <ul>
          <li>Emergency requests prioritized</li>
          <li>Compatibility filtering</li>
          <li>Real-time availability check</li>
        </ul>
      </div>
    </div>
  );
}

export default LeftFlow;