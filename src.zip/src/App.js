import React from 'react';
import './App.css';
import AICore from './components/AICore';
import LeftFlow from './components/LeftFlow';
import RightFlow from './components/RightFlow';
import Footer from './components/Footer';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>AI-Driven Blood Bank Intelligence Network</h1>
        <p className="subtitle">Smart inventory management & donor coordination powered by AI</p>
      </header>

      <main className="App-main">
        <div className="infographic-container">
          {/* Left Flow Section */}
          <LeftFlow />

          {/* Center AI Core */}
          <AICore />

          {/* Right Flow Section */}
          <RightFlow />
        </div>

        {/* Below: Explanatory Bullets & Features */}
        <section className="features-section">
          <h2>Key Features</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">🏥</div>
              <h3>Real-time Inventory</h3>
              <p>Monitor blood stock levels across all branches instantly with AI predictions.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">🤖</div>
              <h3>Smart Matching</h3>
              <p>AI algorithms match donors with recipients based on compatibility and urgency.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">📊</div>
              <h3>Analytics Dashboard</h3>
              <p>Track donation trends, predict demand, and optimize resource allocation.</p>
            </div>
            <div className="feature-card">
              <div className="feature-icon">🔔</div>
              <h3>Smart Alerts</h3>
              <p>Receive notifications for critical shortages and matching opportunities.</p>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="cta-section">
          <button className="btn-start">Start Now</button>
        </section>
      </main>

      <Footer />
    </div>
  );
}

export default App;
